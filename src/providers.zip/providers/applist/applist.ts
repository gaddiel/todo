import { Injectable } from '@angular/core';
import * as Applist from 'cordova-plugin-applist2/www/Applist';

/*
  Generated class for the ApplistProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
declare var Applist: any;
@Injectable()
export class ApplistProvider {
data:any;
  constructor() {

  }
 getlist(){
   console.log('Hello ApplistProvider Provider');
   let success = function(app_list) {
     alert(JSON.stringify((app_list)));
     console.log(JSON.stringify((app_list)));
    };
   let error = function(app_list) {
      alert("Oopsie! " + app_list);
      console.log("Oopsie! " + app_list);
     };
   this.data= new Applist.createEvent('', '', '', '', '', success, error);
   console.log(JSON.stringify((this.data)));
 }
}
